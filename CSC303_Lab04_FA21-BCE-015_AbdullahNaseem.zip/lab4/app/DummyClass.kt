class DummyClass {
}