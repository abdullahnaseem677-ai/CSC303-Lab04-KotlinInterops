package com.example.kotlininteroplab;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAnalyze = findViewById(R.id.btnAnalyze);
        TextView tvReport = findViewById(R.id.tvReport);

        btnAnalyze.setOnClickListener(v -> {
            String report = DeviceAnalyzer.loadAndBuildReport();
            tvReport.setText(report);
        });
    }
}